// miniprogram/pages/kechengyemian.js
Page({
  data: {
    msg: "Hello World"
  }
})